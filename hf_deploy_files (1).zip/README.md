---
title: Elephant Behaviour Dashboard
emoji: 🐘
colorFrom: green
colorTo: gray
sdk: docker
app_port: 7860
pinned: false
---

# Elephant Behaviour Dashboard

Streamlit dashboard with a model selector:

- **Feeding Behaviour (video only)** — YOLO + ByteTrack + MobileNetV3 detects, tracks, and
  classifies each elephant (drinking / eating / resting) and estimates crop loss, with a live
  preview while processing.
- **Calm / Aggressive (video + CSV)** — SVM on window-level features.

Deployed as a Docker Space. The container installs CPU-only PyTorch, so inference runs on CPU
(slower, but free).
