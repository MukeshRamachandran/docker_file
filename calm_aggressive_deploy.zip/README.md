---
title: Elephant Calm Aggressive Dashboard
emoji: 🐘
colorFrom: green
colorTo: red
sdk: docker
app_port: 7860
pinned: false
---

# Elephant Calm / Aggressive Behaviour Dashboard

Streamlit app that predicts elephant behaviour (calm vs aggressive) using a trained SVM model.

Upload an elephant video **and** the matching `window_features.csv`. The model predicts
calm/aggressive per window, shows the overall result, and can render an annotated video
(CALM in green, AGGRESSIVE in red).

Model file expected at `model/best_model_svm.joblib`.
